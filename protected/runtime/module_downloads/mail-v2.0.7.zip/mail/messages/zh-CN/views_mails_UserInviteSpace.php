<?php
return array (
  'Sign up now' => '现在报名',
);
