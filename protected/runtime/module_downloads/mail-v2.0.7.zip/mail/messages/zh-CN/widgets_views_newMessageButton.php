<?php

return [
    'Send message' => '发送消息',
];
