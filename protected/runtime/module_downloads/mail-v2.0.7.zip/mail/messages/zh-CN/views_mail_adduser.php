<?php

return [
    'Add more participants to your conversation...' => '添加更多人参与讨论...',
];
