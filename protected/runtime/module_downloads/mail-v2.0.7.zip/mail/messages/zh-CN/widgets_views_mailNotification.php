<?php

return [
    'Show all messages' => '显示所有的信息',
];
