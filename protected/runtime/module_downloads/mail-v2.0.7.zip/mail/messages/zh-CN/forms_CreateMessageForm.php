<?php
return array (
  'Message' => '消息',
  'Recipient' => '收件人',
  'Subject' => '主题',
  'Tags' => '标签',
);
