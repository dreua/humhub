<?php
return array (
  '<strong>New</strong> message' => '新<strong>消息</strong>',
  'Add recipients' => '增加收件人',
  'Send' => '发送',
);
