<?php
return array (
  'There are no messages yet.' => 'Još nema poruka.',
);
