<?php
return array (
  'Show all messages' => 'Prikaži sve poruke',
);
