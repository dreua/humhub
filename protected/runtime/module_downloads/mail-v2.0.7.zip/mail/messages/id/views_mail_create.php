<?php

return [
    'Send' => 'Kirim',
    '<strong>New</strong> message' => '',
    'Add recipients' => '',
];
