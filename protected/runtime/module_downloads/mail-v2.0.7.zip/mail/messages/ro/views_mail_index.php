<?php
return array (
  'Conversations' => '',
  'New' => 'Noi',
  'There are no messages yet.' => '',
);
