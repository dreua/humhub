<?php

return [
    'Show all messages' => '',
];
