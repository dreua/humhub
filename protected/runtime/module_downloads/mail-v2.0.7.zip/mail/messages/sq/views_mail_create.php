<?php
return array (
  '<strong>New</strong> message' => '',
  'Add recipients' => '',
  'Send' => 'Dërgo',
);
