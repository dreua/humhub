<?php
return array (
  'Message' => 'Besked',
);
