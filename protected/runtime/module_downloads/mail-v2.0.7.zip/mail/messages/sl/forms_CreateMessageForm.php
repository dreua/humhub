<?php

return [
    'Message' => '',
    'Recipient' => '',
    'Subject' => '',
    'Tags' => '',
];
