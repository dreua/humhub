<?php
return array (
  '<strong>New</strong> message' => 'Tin nhắn <strong>mới</strong>',
  'Add recipients' => 'Thêm người nhận',
  'Send' => 'Gửi',
);
