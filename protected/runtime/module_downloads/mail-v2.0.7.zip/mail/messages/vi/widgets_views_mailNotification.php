<?php

return [
    'Show all messages' => 'Hiển thị toàn bộ tin nhắn',
];
