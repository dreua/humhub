<?php
return array (
  'sent you a new message in' => 'đã gửi bạn một tin nhắn mới trong',
);
