<?php
return array (
  'New message in discussion from %displayName%' => 'Tin nhắn mới trong cuộc thảo luận từ %displayName%',
);
