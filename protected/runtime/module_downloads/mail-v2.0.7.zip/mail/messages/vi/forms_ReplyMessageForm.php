<?php
return array (
  'Message' => 'Tin nhắn',
);
