<?php
return array (
  'There are no messages yet.' => 'Chưa có tin nhắn nào.',
);
