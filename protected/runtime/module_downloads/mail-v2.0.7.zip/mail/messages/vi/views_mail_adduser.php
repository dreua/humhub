<?php

return [
    'Add more participants to your conversation...' => 'Thêm người tham gia vào cuộc hội thoại...',
];
