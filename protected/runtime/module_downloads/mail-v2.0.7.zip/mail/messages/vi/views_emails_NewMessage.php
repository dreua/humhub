<?php

return [
    '<strong>New</strong> message' => 'Tin nhắn <strong>mới</strong>',
    'Reply now' => 'Trả lời bây giờ',
];
