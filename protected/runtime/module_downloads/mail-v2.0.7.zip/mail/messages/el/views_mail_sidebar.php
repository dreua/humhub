<?php
return array (
  'Groups' => 'Ομάδες',
  'Members' => 'Μέλη',
  'Spaces' => 'Χώροι',
  'User Posts' => '',
);
