<?php

return [
    'Send' => 'Στείλε',
    '<strong>New</strong> message' => '',
    'Add recipients' => '',
];
