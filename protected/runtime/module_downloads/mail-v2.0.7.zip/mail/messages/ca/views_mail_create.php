<?php
return array (
  '<strong>New</strong> message' => '<strong>Nou</strong> missatge',
  'Add recipients' => 'Afegeix destinataris',
  'Send' => 'Envia',
);
