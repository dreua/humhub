<?php
return array (
  'Message' => 'Missatge',
  'Recipient' => 'Destinatari',
  'Subject' => 'Assumpte',
  'Tags' => 'Etiquetes',
);
