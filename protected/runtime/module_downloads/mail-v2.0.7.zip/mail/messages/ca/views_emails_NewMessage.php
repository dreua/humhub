<?php

return [
    '<strong>New</strong> message' => '<strong>Nou</strong> missatge',
    'Reply now' => 'Respon ara',
];
