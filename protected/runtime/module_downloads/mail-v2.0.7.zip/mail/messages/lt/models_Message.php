<?php

return [
    'New message from {senderName}' => 'Nauja žinutė nuo {senderName}',
];
