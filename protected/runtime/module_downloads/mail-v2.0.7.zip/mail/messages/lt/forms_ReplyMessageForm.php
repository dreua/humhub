<?php
return array (
  'Message' => 'Žinutė',
);
