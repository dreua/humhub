<?php
return array (
  'sent you a new message in' => 'atsiuntė Jums naują žinutę į',
);
