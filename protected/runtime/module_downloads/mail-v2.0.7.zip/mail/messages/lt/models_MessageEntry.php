<?php
return array (
  'New message in discussion from %displayName%' => 'Pokalbyje nauja žinutė nuo %displayName%',
);
