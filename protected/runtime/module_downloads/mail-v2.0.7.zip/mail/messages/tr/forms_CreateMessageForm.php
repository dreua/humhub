<?php
return array (
  'Message' => 'Mesaj',
  'Recipient' => 'Alıcı',
  'Subject' => 'Konu',
  'Tags' => 'Etiketler',
);
