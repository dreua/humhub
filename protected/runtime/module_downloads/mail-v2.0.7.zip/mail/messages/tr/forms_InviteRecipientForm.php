<?php

return [
    'User {name} is already participating!' => '',
    'You are not allowed to send user {name} is already!' => '',
    'Recipient' => 'Alıcı',
    'You cannot send a email to yourself!' => 'Kendinize e-posta gönderemessiniz!',
];
