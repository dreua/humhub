<?php

return [
    '<strong>Confirm</strong> deleting conversation' => '<strong>Konuşmayı</strong> sil',
    '<strong>Confirm</strong> leaving conversation' => '<strong>Konuşmadan</strong> ayrıl',
    '<strong>Confirm</strong> message deletion' => '<strong>Mesajı</strong> sil',
    'Add user' => 'Kullanıcı ekle',
    'Cancel' => 'İptal',
    'Delete' => 'Sil',
    'Delete conversation' => 'Konuşmayı sil',
    'Do you really want to delete this conversation?' => 'Konuşmayı silmek istiyor musun?',
    'Do you really want to delete this message?' => 'Mesajı silmek istiyor musun?',
    'Do you really want to leave this conversation?' => 'Konuşmadan ayrılmak istiyor musun?',
    'Leave' => 'Ayrıl',
    'Leave conversation' => 'Konuşmadan ayrıl',
    'There are no messages yet.' => 'Henüz mesaj bulunmuyor.',
];
