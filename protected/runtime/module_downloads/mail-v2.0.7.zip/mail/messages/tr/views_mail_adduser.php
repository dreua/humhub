<?php

return [
    'Add more participants to your conversation...' => 'Konuşmaya daha fazla katılımcı ekleyin...',
];
