<?php

return [
    'Show all messages' => 'Mostrar todas as mensagens',
];
