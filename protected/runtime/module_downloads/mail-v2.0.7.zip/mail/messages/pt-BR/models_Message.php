<?php

return [
    'New message from {senderName}' => 'Nova mensagem de {senderName}',
];
