<?php
return array (
  'Recipient' => 'Destinatário',
  'User {name} is already participating!' => 'O usuário {name} já está participando!',
  'You are not allowed to send user {name} is already!' => 'Você ainda não pode enviar uma mensagem ao usuário {name}!',
  'You cannot send a email to yourself!' => 'Você NÃO PODE enviar um e-mail para si mesmo!',
);
