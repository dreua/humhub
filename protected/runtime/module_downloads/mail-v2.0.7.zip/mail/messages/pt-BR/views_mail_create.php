<?php
return array (
  '<strong>New</strong> message' => '<strong>Nova</strong> mensagem',
  'Add recipients' => 'Adicionar destinatários',
  'Send' => 'Enviar',
);
