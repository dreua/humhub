<?php

return [
    '<strong>New</strong> message' => '<strong>Nova</strong> mensagem',
    'Reply now' => 'Responder agora',
];
