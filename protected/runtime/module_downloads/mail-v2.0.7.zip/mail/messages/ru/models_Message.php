<?php

return [
    'New message from {senderName}' => 'Новое сообщение от {senderName}',
];
