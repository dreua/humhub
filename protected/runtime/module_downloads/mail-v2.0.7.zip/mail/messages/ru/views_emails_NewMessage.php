<?php

return [
    '<strong>New</strong> message' => '<strong>Новое</strong> сообщение',
    'Reply now' => 'Ответить сейчас',
];
