<?php

return [
    'User {name} is already participating!' => '',
    'You are not allowed to send user {name} is already!' => '',
    'Recipient' => 'Получатель',
    'You cannot send a email to yourself!' => 'Вы не можете отправить сообщение самому себе!',
];
