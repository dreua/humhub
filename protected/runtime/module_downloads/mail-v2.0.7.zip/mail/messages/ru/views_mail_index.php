<?php

return [
    'Conversations' => '',
    'New' => 'Новое',
    'There are no messages yet.' => 'Здесь пока нет сообщений.',
];
