<?php
return array (
  'Show all messages' => 'הצג את כל ההודעות',
);
