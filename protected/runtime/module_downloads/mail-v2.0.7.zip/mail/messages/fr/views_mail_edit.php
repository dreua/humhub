<?php

return [
    'Edit message entry' => 'Modifier le message',
];
