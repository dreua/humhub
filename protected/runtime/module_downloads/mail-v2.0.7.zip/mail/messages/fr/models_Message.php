<?php

return [
    'New message from {senderName}' => 'Nouveau message de {senderName}',
];
