<?php
return array (
  'Message' => '訊息',
);
