<?php

return [
    'Message' => '訊息',
    'Recipient' => '',
    'Subject' => '',
    'Tags' => '',
];
