<?php
return array (
  'Groups' => '',
  'Members' => '',
  'Spaces' => '空間',
  'User Posts' => '',
);
