<?php

return [
    'Edit message entry' => 'ویرایش ورودی پیغام',
];
