<?php

return [
    'Show all messages' => 'نمایش همه‌ی پیغام‌ها',
];
