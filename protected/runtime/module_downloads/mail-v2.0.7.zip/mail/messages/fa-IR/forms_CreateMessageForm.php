<?php
return array (
  'Message' => 'پیغام',
  'Recipient' => 'گیرنده',
  'Subject' => 'موضوع',
  'Tags' => 'تگ‌ها',
);
