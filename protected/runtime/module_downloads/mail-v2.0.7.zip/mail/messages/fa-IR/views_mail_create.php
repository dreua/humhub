<?php
return array (
  '<strong>New</strong> message' => 'پیغام <strong>جدید</strong>',
  'Add recipients' => 'اضافه كردن گيرنده',
  'Send' => 'ارسال',
);
