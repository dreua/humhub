<?php

return [
    'Send message' => 'ارسال پیغام',
];
