<?php
return array (
  '<strong>New</strong> message' => '<strong>Új</strong> üzenet',
  'Reply now' => 'Válasz most',
);
