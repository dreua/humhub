<?php
return array (
  '<strong>New</strong> message' => '<strong>Új</strong> üzenet',
  'Add recipients' => 'Címzett(ek)',
  'Send' => 'Küldés',
);
