<?php
return array (
  'Recipient' => 'Címzett',
  'User {name} is already participating!' => '{name} már a résztvevők között szerepel!',
  'You are not allowed to send user {name} is already!' => 'Nem küldhetsz üzenetet a következőnek: {name}',
  'You cannot send a email to yourself!' => 'Magadnak nem küldhetsz üzenetet!',
);
