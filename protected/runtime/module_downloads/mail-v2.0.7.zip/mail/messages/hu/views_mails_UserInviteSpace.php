<?php
return array (
  'Sign up now' => 'Feliratkozás most',
);
