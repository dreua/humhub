<?php

return [
    'New message from {senderName}' => '{senderName} új üzenetet küldött',
];
