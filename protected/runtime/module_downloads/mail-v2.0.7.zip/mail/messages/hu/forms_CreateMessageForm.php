<?php
return array (
  'Message' => 'Üzenet',
  'Recipient' => 'Címzett',
  'Subject' => 'Tárgy',
  'Tags' => 'Címkék',
);
