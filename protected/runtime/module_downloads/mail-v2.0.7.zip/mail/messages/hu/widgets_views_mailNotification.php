<?php

return [
    'Show all messages' => 'Összes üzenet mutatása',
];
