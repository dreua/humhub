<?php
return array (
  '<strong>New</strong> message' => '<strong>Nowa</strong> wiadomość ',
  'Add recipients' => 'Dodaj odbiorców',
  'Send' => 'Wyślij ',
);
