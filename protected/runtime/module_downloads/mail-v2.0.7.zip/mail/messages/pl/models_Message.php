<?php

return [
    'New message from {senderName}' => 'Nowa wiadomość od {senderName} ',
];
