<?php

return [
    'Send message' => 'Wyślij wiadomość',
];
