<?php

return [
    'Show all messages' => 'Mostra tutti i messaggi',
];
