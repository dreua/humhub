<?php
return array (
  'Message' => 'Messaggio',
  'Recipient' => 'Destinatario',
  'Subject' => 'Soggetto',
  'Tags' => 'Tag',
);
