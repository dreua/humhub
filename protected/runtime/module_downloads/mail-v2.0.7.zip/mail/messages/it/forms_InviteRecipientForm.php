<?php
return array (
  'Recipient' => 'Destinatario',
  'User {name} is already participating!' => 'L\'utente {name} sta già partecipando!',
  'You are not allowed to send user {name} is already!' => 'Non puoi inviare all\'utente {name}!',
  'You cannot send a email to yourself!' => 'Non puoi inviare un\'email a te stesso!',
);
