<?php

return [
    'Conversations' => 'Conversazioni',
    'New' => 'Nuovo',
    'There are no messages yet.' => 'Non c\'è alcun altro messaggio.',
];
