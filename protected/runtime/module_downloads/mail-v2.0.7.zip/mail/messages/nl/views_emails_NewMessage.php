<?php

return [
    '<strong>New</strong> message' => '<strong>Nieuw</strong> bericht',
    'Reply now' => 'Antwoord nu',
];
