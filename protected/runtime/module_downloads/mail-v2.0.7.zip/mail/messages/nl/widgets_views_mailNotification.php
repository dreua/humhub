<?php

return [
    'Show all messages' => 'Toon alle berichten',
];
