<?php

return [
    'Send message' => 'Verstuur bericht',
];
