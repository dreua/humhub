<?php
return array (
  'Sign up now' => 'Anmäl dig nu',
);
