<?php
return array (
  '<strong>New</strong> message' => '<strong>Nytt</strong> meddelande',
  'Add recipients' => 'Lägg till mottagare',
  'Send' => 'Skicka',
);
