<?php
return array (
  'Message' => 'Medelande',
  'Recipient' => 'Mottagare',
  'Subject' => 'Ämne',
  'Tags' => 'Taggar',
);
