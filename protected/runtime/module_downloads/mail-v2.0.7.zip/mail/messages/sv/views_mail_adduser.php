<?php
return array (
  'Add more participants to your conversation...' => 'Lägg till fler deltagare i din diskussion...',
);
