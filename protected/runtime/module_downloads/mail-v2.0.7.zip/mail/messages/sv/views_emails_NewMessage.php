<?php

return [
    '<strong>New</strong> message' => '<strong>Nytt</strong> medelande',
    'Reply now' => 'Svara nu',
];
